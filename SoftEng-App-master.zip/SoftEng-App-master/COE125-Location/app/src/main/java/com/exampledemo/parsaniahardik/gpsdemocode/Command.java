package com.exampledemo.parsaniahardik.gpsdemocode;

/**
 * Created by Jzon on 8/6/2017.
 */

public class Command {
    String userComm;
    //String userName;

    public Command(String userComm) {
        this.userComm = userComm;
        //this.userName = userName;
    }

    //public String getUserID() {
     //   return userName;
    //}
    public String getUserComm() {return userComm;
    }
}
